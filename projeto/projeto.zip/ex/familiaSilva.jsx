import React from 'react';
import Membro from './membro';

export default props => (
  <div>
    <Membro nome="João" sobrenome="Silva" />
    <Membro nome="Maria" sobrenome="Silva" />
    <Membro nome="José" sobrenome="Silva" />
    <Membro nome="Pedro" sobrenome="Silva" />
  </div>
);
