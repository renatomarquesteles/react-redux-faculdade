import React from 'react';

export default props => (
  <div>
    Nome: {props.nome} <strong>{props.sobrenome}</strong>
  </div>
);
